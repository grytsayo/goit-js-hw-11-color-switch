goit-js-hw-11-color-switch
